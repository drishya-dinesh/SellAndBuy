export const environment = {
  firebase: {
    projectId: 'test-21c6c',
    appId: '1:265274952614:web:3f2be7b112c8e5809d5d67',
    storageBucket: 'test-21c6c.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyDisC7pdSA7cx2EkzriggJe1ykfq6hgDO4',
    authDomain: 'test-21c6c.firebaseapp.com',
    messagingSenderId: '265274952614',
  },
  production: true,
};
