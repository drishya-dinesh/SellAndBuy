export const COLLECTIONS = {
    ALL_ADS: 'ALL_ADS',
    USERS: 'USERS', 
    CHATS: 'CHATS'
}